#ifndef __SERIALCOM_H
#define __SERIALCOM_H

#include <Arduino.h>

int** solvedNono(int *dimensions);

#endif
